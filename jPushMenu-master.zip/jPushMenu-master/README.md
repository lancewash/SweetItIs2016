# jPushMenu

A jQuery version of Slide and Push Menus

Demo http://takien.github.io/jPushMenu/


# Development

Install [Bower](http://bower.io) on your local machine first, then run:

```sh
bower install
```

This will install jQuery on `bower_components` directory on your local machine.
Copy/paste jQuery file into js directory
